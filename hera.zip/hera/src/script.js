document.getElementById('calendarForm').addEventListener('submit', function (e) {

  e.preventDefault();

  const startDate = new Date(document.getElementById('startDate').value);

  const periodLength = parseInt(document.getElementById('periodLength').value);

  const cycleLength = parseInt(document.getElementById('cycleLength').value);

  const results = document.getElementById('results');

  if (isNaN(startDate.getTime()) || isNaN(periodLength) || isNaN(cycleLength)) {

    results.innerHTML = "<p>Por favor ingresa datos válidos.</p>";

    return;

  }

  const nextPeriod = new Date(startDate);

  nextPeriod.setDate(startDate.getDate() + cycleLength);

  const ovulation = new Date(startDate);

  ovulation.setDate(startDate.getDate() + (cycleLength - 14));

  results.innerHTML = `

    <p><strong>Próximo período estimado:</strong> ${nextPeriod.toLocaleDateString()}</p>

    <p><strong>Ovulación estimada:</strong> ${ovulation.toLocaleDateString()}</p>

  `;

});
function abrirModal() {
  document.getElementById("modalEdad").style.display = "block";
}

window.onclick = function (event) {
  if (event.target == document.getElementById("modalEdad")) {
    document.getElementById("modalEdad").style.display = "none";
  }
};

function mostrarConsejos() {
  const edad = parseInt(document.getElementById("edadInput").value);
  const articulos = document.getElementById("articulos");
  const consejos = document.getElementById("consejos");
  articulos.innerHTML = "";

  let contenido = [];

  if (edad >= 10 && edad <= 14) {
    contenido = [
      { titulo: "Tu primer período: ¿Qué esperar?", texto: "Guía básica sobre la menarquía y consejos para estar preparada." },
      { titulo: "Cómo usar productos menstruales", texto: "Toallas, tampones y copas: una introducción sencilla." }
    ];
  } else if (edad <= 19) {
    contenido = [
      { titulo: "¿Por qué es irregular mi ciclo?", texto: "Explicación sobre los cambios hormonales normales en la adolescencia." },
      { titulo: "SPM y cómo aliviarlo", texto: "Consejos prácticos para manejar los síntomas del síndrome premenstrual." }
    ];
  } else if (edad <= 29) {
    contenido = [
      { titulo: "Fertilidad y anticoncepción", texto: "Lo que debes saber para cuidar tu salud reproductiva." },
      { titulo: "Tu ciclo y el ejercicio físico", texto: "Cómo adaptar tu actividad física al ciclo menstrual." }
    ];
  } else if (edad <= 39) {
    contenido = [
      { titulo: "Planificación familiar consciente", texto: "Todo sobre métodos modernos y naturales." },
      { titulo: "Alimentación y ciclo hormonal", texto: "Nutrientes clave para una menstruación saludable." }
    ];
  } else {
    contenido = [
      { titulo: "¿Qué es la perimenopausia?", texto: "Síntomas y formas de afrontarla con bienestar." },
      { titulo: "Cuida tus huesos y hormonas", texto: "Consejos para esta nueva etapa hormonal." }
    ];
  }

  contenido.forEach(item => {
    const div = document.createElement("div");
    div.className = "articulo";
    div.innerHTML = `<h3>${item.titulo}</h3><p>${item.texto}</p>`;
    articulos.appendChild(div);
  });

  document.getElementById("modalEdad").style.display = "none";
  consejos.style.display = "block";
  consejos.scrollIntoView({ behavior: "smooth" });
}
function mostrarSeccion(id) {
  const secciones = document.querySelectorAll(".pagina");
  secciones.forEach(seccion => seccion.style.display = "none");
  document.getElementById(id).style.display = "block";
}
